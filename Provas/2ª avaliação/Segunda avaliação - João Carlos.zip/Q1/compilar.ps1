gcc -o main ./RedBlackTree/rbt_node.c ./RedBlackTree/rbt.c  ./RedBlackTree/LinkedList/data.c ./RedBlackTree/LinkedList/simple_linked_list.c file.c main.c
.\main