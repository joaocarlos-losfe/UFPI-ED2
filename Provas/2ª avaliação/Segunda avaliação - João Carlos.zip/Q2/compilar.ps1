gcc -o main ./2_3Tree/LinkedList/data.c ./2_3Tree/LinkedList/simple_linked_list.c ./2_3Tree/dtt_node.c ./2_3Tree/dtt.c file.c main.c
.\main