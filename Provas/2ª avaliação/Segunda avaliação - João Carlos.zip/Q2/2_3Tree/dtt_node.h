#ifndef _23TNODE_H_
#define _23TNODE_H_

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

#include "LinkedList/simple_linked_list.h"

typedef struct DTNode * DTNode;

struct DTNode
{
    DTNode left;
	char palavra_left[50]; 
	DTNode cen;
    char palavra_right[50]; 
	DTNode right;

	List linhasPalavraLeft;
	List linhasPalavraRight;

	int total_keys;  
};

DTNode dttCreateNode(char *palavra, DTNode left, DTNode cen);
bool isLeaf(DTNode node);
void dtNodePrint(DTNode node);

#endif