#include "dtt_node.h"

DTNode dttCreateNode(char *palavra, DTNode left, DTNode cen)
{
	DTNode new_node = malloc(sizeof(struct DTNode));
	
	strcpy(new_node->palavra_left, palavra); new_node->linhasPalavraLeft = listCreate();
	strcpy(new_node->palavra_right, ""); new_node->linhasPalavraRight = listCreate();

	new_node->left = left;
	new_node->cen = cen;
	new_node->right = NULL;

	new_node->total_keys = 1;
	return new_node;
	
}

bool isLeaf(DTNode node)
{
	if (node->left == NULL && node->cen == NULL && node->right == NULL)
		return true;
	
	return false;	
}

void dtNodePrint(DTNode node)
{
	printf("%s %s total de infos: %d\n", node->palavra_left, node->palavra_right, node->total_keys);

}