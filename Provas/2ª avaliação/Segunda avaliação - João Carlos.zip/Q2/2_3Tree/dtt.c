#include "dtt.h"

DTT dttStart()
{
    DTT new_tree = malloc(sizeof(struct DTT));
    new_tree->total_infos = 0;

    return new_tree;
}

void dttPrint(DTNode root)
{
	if (root != NULL)
	{
		printf("%s [ ", root->palavra_left);
		listPrint(root->linhasPalavraLeft);
		printf(" ]");
		
		if(strcmp(root->palavra_right, "") != 0)
		{
			printf(" %s [ ", root->palavra_right);
			listPrint(root->linhasPalavraRight);
			printf(" ]");
		}

		printf("\n");
			
		dttPrint(root->left);
		dttPrint(root->cen);
		dttPrint(root->right);
	}
}

void getTotalNodes(DTNode root, int *count)
{
	if (root != NULL)
	{
		*count = *count + root->total_keys;

		getTotalNodes(root->left, count);
		getTotalNodes(root->cen, count);
		getTotalNodes(root->right, count);
	}
}

DTNode dttSeach(DTNode node, char *palavra)
{
	if(node == NULL)
		return NULL;
	if (strcmp(palavra, node->palavra_left) == 0 || strcmp(palavra, node->palavra_right) == 0)
		return node; 

	else if (strcmp(palavra, node->palavra_left) < 0)
		return dttSeach(node->left, palavra);
	else if(strcmp(palavra, node->palavra_left) > 0 && strcmp(node->palavra_right, "") == 0)
		return dttSeach(node->cen, palavra);
	else if(strcmp(palavra, node->palavra_left) > 0 && strcmp(palavra, node->palavra_right) > 0)
		return dttSeach(node->right, palavra);
	else 
		return dttSeach(node->cen, palavra);
	
}

DTNode insertNode(DTNode root, char *palavra, DTNode new)
{
	if (palavra > root->palavra_left)
	{
		strcpy(root->palavra_right, palavra);
		root->right = new;
	}
	else
	{
		strcpy(root->palavra_right, root->palavra_left);
		strcpy(root->palavra_left, palavra);

		root->right = root->cen;
		root->cen = new;
	}

	root->total_keys = 2;

	return root;
	
}

DTNode explodeNode(DTNode *root, DTNode new_node, char *palavra, char *palavra_cen)
{
	DTNode new;

	if (strcmp(palavra, (*root)->palavra_right) > 0)
	{
		strcpy(palavra_cen, (*root)->palavra_right);

		new = dttCreateNode(palavra, (*root)->right, new_node);
	}
	else if (strcmp(palavra, (*root)->palavra_left) < 0)
	{
		strcpy(palavra_cen, (*root)->palavra_left);

		new = dttCreateNode((*root)->palavra_right, (*root)->cen, (*root)->right);

		strcpy((*root)->palavra_left, palavra);

		(*root)->cen = new_node;
	}
	else
	{
		strcpy(palavra_cen, palavra);
		new = dttCreateNode((*root)->palavra_right, new_node, (*root)->right);
	}

	strcpy((*root)->palavra_right, "");
	(*root)->total_keys = 1;
	(*root)->right = NULL;

	return new;
}

DTNode ddtInsert(DTNode parent, DTNode *root, char *palavra, char *palavra_cen)
{
	DTNode new;
	
	if (*root == NULL)
	{
		*root = dttCreateNode(palavra, NULL, NULL);
	}
	else
	{
		if (isLeaf(*root))
		{
			if ((*root)->total_keys == 1)
			{
				*root = insertNode(*root, palavra, NULL);
				new = NULL;
			}
			else
			{
				new = explodeNode(root, NULL, palavra, palavra_cen);

				if (parent == NULL)
				{
					*root = dttCreateNode(palavra_cen, *root, new);
					new = NULL;
				}
			}
		}
		else
		{
			if (strcmp(palavra, (*root)->palavra_left) < 0)
				new = ddtInsert(*root, &(*root)->left, palavra, palavra_cen);
			
			else if((*root)->total_keys == 1)
				new = ddtInsert(*root, &(*root)->cen, palavra, palavra_cen);
			
			else if(strcmp(palavra, (*root)->palavra_right) < 0)
				new = ddtInsert(*root, &(*root)->cen, palavra, palavra_cen);
			else
				new = ddtInsert(*root, &(*root)->right, palavra, palavra_cen);
			
			if(new != NULL)
			{
				if((*root)->total_keys == 1)
				{
					*root = insertNode(*root, palavra_cen, new);
					new = NULL;
				}
				else
				{
					new = explodeNode(root, new, palavra_cen, palavra_cen);

					if (parent == NULL)
					{
						*root = dttCreateNode(palavra_cen, *root, new);
						new = NULL; 
					}
					
				}
			}
			
		}
		
	}
	
	return new;
}


int contains(DTNode root, char *palavra)
{
	if (strcmp(palavra, root->palavra_left))
		return 1; // se esta na informa��o da esquerda
	else if (strcmp(palavra, root->palavra_right))
		return 2; // se esta na informa��o da direita
	
	return 0; // em nenhuma das infos
}

int dttDelete(DTNode *parent, DTNode *root, char *palavra)
{

	if (*root != NULL)
	{
		if (contains(*root, palavra) != 0)
		{
			if (*parent == NULL && isLeaf(*root))
			{
				if (contains(*root, palavra) == 1)
					strcpy((*root)->palavra_left, (*root)->palavra_right);
				
				strcpy((*root)->palavra_right, "");

				if((*root)->total_keys == 2)
					(*root)->total_keys = 1;
				else
					*root = NULL;
			}
			else if(*parent == NULL)
			{
				if((*root)->total_keys == 2)
				{
					if(contains(*root, palavra) == 2 && (*root)->right->total_keys == 2)
					{
						strcpy((*root)->palavra_right,(*root)->right->palavra_left);
						strcpy((*root)->right->palavra_left, (*root)->right->palavra_right);
						strcpy((*root)->right->palavra_right, "");
						(*root)->right->total_keys = 1;
					}
					else if(contains(*root, palavra) == 2 && (*root)->cen->total_keys ==2)
					{
						strcpy((*root)->palavra_right, (*root)->cen->palavra_right);
						strcpy((*root)->cen->palavra_right, "");
						(*root)->right->total_keys = 1;
					}
					else if(contains(*root, palavra) == 2 && (*root)->left->total_keys == 2)
					{
						strcpy((*root)->palavra_right, "");
						(*root)->total_keys = 1;
						strcpy((*root)->cen->palavra_right, (*root)->right->palavra_left);
						(*root)->cen->total_keys = 2;
						(*root)->right = NULL;
					}
					else if(contains(*root, palavra) == 2 && (*root)->left->total_keys == 1)
					{
						strcpy((*root)->palavra_right, "");
						(*root)->total_keys = 1;
						strcpy((*root)->cen->palavra_right, (*root)->right->palavra_left);
						(*root)->cen->total_keys = 2;
						(*root)->right = NULL;
					}
					else if(contains(*root, palavra) == 1 && (*root)->cen->total_keys == 2)
					{
						strcpy((*root)->palavra_left, (*root)->cen->palavra_left);
						strcpy((*root)->cen->palavra_left, (*root)->cen->palavra_right);
						strcpy((*root)->cen->palavra_right, "");
						(*root)->cen->total_keys = 1;
					}
					else if(contains(*root, palavra) == 1 && (*root)->left->total_keys == 2)
					{
						strcpy((*root)->palavra_left, (*root)->left->palavra_right);
						strcpy((*root)->left->palavra_right, "");
						(*root)->left->total_keys = 1;
					}
					else if (contains(*root, palavra) == 1 && (*root)->cen->total_keys == 1)
					{
						strcpy((*root)->palavra_left, (*root)->palavra_right);
						strcpy((*root)->palavra_right, "");
						(*root)->total_keys = 1;
						strcpy((*root)->left->palavra_right, (*root)->cen->palavra_left);
						(*root)->left->total_keys = 2;
						(*root)->cen = NULL;
					}
					else if ((*root)->total_keys == 1)
					{
						if((*root)->cen->total_keys == 2)
						{
							strcpy((*root)->palavra_left, (*root)->cen->palavra_left);
							strcpy((*root)->cen->palavra_left, (*root)->cen->palavra_right);
							strcpy((*root)->cen->palavra_right, "");
							(*root)->cen->total_keys = 1;
						}
						else if((*root)->left->total_keys == 2)
						{
							strcpy((*root)->palavra_left, (*root)->left->palavra_right);
							strcpy((*root)->left->palavra_right, "");
							(*root)->left->total_keys = 1;
						}
						else
						{
							strcpy((*root)->left->palavra_right, (*root)->cen->palavra_left);
							(*root)->left->total_keys = 2;
							(*root)->right = NULL;
							*root = (*root)->left; 
						}
					}	
				}
			}
			else if(*parent != NULL && isLeaf(*root))
			{
				if ((*root)->total_keys == 2)
				{
					if(contains(*root, palavra) == 1)
						strcpy((*root)->palavra_left, (*root)->palavra_right);
					
					strcpy((*root)->palavra_right, "");
					(*root)->total_keys = 1;
				}
				else if ((*parent)->total_keys == 2)
				{
					if (strcmp(palavra, (*parent)->palavra_right) > 0 && (*parent)->cen->total_keys == 2)
					{
						strcpy((*root)->palavra_left, (*parent)->palavra_right);
						strcpy((*parent)->palavra_right, (*parent)->cen->palavra_right);
						strcpy((*parent)->cen->palavra_right, "");
						(*parent)->cen->total_keys = 1;
					}
					else if(strcmp(palavra, (*parent)->palavra_right) > 0 && (*parent)->cen->total_keys == 1)
					{
						strcpy((*parent)->cen->palavra_right, (*parent)->palavra_right);
						(*parent)->cen->total_keys = 2;
						strcpy((*parent)->palavra_right,  "");
						(*parent)->total_keys = 1;
						*root = NULL; 
					}
					else if(strcmp(palavra, (*parent)->palavra_left) > 0 && (*parent)->right->total_keys == 2)
					{
						strcpy((*root)->palavra_left, (*parent)->palavra_right);
						strcpy((*parent)->palavra_right, (*parent)->right->palavra_left);
						strcpy((*parent)->right->palavra_left, (*parent)->right->palavra_right);
						strcpy((*parent)->right->palavra_right, "");
						(*parent)->right->total_keys = 1;
					}
					else if(strcmp(palavra, (*parent)->palavra_left) > 0 && (*parent)->right->total_keys == 1)
					{
						strcpy((*root)->palavra_left, (*parent)->palavra_right);
						strcpy((*root)->palavra_right, (*parent)->right->palavra_left);
						(*root)->total_keys = 2;
						strcpy((*parent)->palavra_right,  "");
						(*parent)->total_keys = 1;
						(*parent)->right = NULL;
					}

					else if(strcmp(palavra, (*parent)->palavra_left) < 0 && (*parent)->cen->total_keys == 2)
					{
						strcpy((*root)->palavra_left, (*parent)->palavra_left);
						strcpy((*parent)->palavra_left, (*parent)->cen->palavra_left);
						strcpy((*parent)->cen->palavra_left, (*parent)->cen->palavra_right);
						strcpy((*parent)->cen->palavra_right, "");
						(*parent)->cen->total_keys = 1;
					}
					else if (strcmp(palavra, (*parent)->palavra_left) < 0 && (*parent)->right->total_keys == 2)
					{
						strcpy((*root)->palavra_left, (*parent)->palavra_left);
						strcpy((*parent)->palavra_left, (*parent)->cen->palavra_left);
						strcpy((*parent)->cen->palavra_left, (*parent)->palavra_right);
						
						strcpy((*parent)->palavra_right, (*parent)->right->palavra_left);
						strcpy((*parent)->right->palavra_left, (*parent)->right->palavra_right);
						strcpy((*parent)->right->palavra_right, "");
						(*parent)->right->total_keys = 1;
					}
					else
					{
						strcpy((*root)->palavra_left, (*parent)->palavra_left);
						strcpy((*parent)->palavra_left, (*parent)->cen->palavra_left);
						strcpy((*parent)->cen->palavra_left, (*parent)->palavra_right);
						strcpy((*parent)->palavra_right,  "");
						(*parent)->total_keys = 1;
						strcpy((*parent)->cen->palavra_right, (*parent)->right->palavra_left);
						(*parent)->cen->total_keys = 2;
						(*parent)->right = NULL;
					}
				}
				
				else
				{
					if (strcmp(palavra, (*parent)->palavra_left) > 0 && (*parent)->left->total_keys == 2)
					{
						strcpy((*root)->palavra_left, (*parent)->palavra_left);
						strcpy((*parent)->palavra_left, (*parent)->left->palavra_right);
						strcpy((*parent)->left->palavra_right, "");
						(*parent)->left->total_keys = 1;
					}
					else if (strcmp(palavra, (*parent)->palavra_left) < 0 && (*parent)->cen->total_keys == 2)
					{
						strcpy((*root)->palavra_left, (*parent)->palavra_left);
						strcpy((*parent)->palavra_left, (*parent)->cen->palavra_left);
						strcpy((*parent)->cen->palavra_left, (*parent)->cen->palavra_right);
						strcpy((*parent)->cen->palavra_right, "");
						(*parent)->cen->total_keys = 1;
					}
					else if(strcmp(palavra, (*parent)->palavra_left) < 0)
					{
						strcpy((*root)->palavra_left, (*parent)->palavra_left);
						strcpy((*root)->palavra_right, (*parent)->cen->palavra_left);
						(*root)->total_keys = 2;
						*parent = *root;
					}
					else
					{
						strcpy((*parent)->left->palavra_right, (*parent)->palavra_left);
						(*parent)->left->total_keys = 2;
						*parent = (*parent)->left;
					}	
				}
			}

			else if(*parent != NULL && !isLeaf(*root))
			{
				if(contains(*root, palavra) == 2)
				{
					if ((*root)->right->total_keys == 2)
					{
						strcpy((*root)->palavra_right,(*root)->right->palavra_left);
						strcpy((*root)->right->palavra_left, (*root)->right->palavra_right);
						strcpy((*root)->right->palavra_right, "");
						(*root)->right->total_keys = 1;
					}
					else if((*root)->cen->total_keys == 2)
					{
						strcpy((*root)->palavra_right, (*root)->cen->palavra_right);
						strcpy((*root)->cen->palavra_right, "");
						(*root)->cen->total_keys = 1;
					}
					else
					{
						strcpy((*root)->cen->palavra_right, (*root)->right->palavra_left);
						(*root)->cen->total_keys = 2;
						strcpy((*root)->palavra_right, "");
						(*root)->total_keys = 2;
						(*root)->right = NULL;
					}	
				}
				else if (contains(*root, palavra) == 1)
				{
					if ((*root)->cen->total_keys == 2)
					{
						strcpy((*root)->palavra_left, (*root)->cen->palavra_left);
						strcpy((*root)->cen->palavra_left, (*root)->cen->palavra_right);
						strcpy((*root)->cen->palavra_right, "");
						(*root)->cen->total_keys = 1;
					}
					else if((*root)->left->total_keys == 2)
					{
						strcpy((*root)->palavra_left, (*root)->left->palavra_right);
						strcpy((*root)->left->palavra_right, "");
						(*root)->left->total_keys = 1;
					}
					else
					{
						strcpy((*root)->palavra_left, (*root)->cen->palavra_left);
						strcpy((*root)->cen->palavra_left, (*root)->palavra_right);
						strcpy((*root)->palavra_right,(*root)->right->palavra_left);
						strcpy((*root)->right->palavra_left, (*root)->right->palavra_right);
						strcpy((*root)->right->palavra_right, "");
						(*root)->right->total_keys = 1;
					}
				}
			}
			
		}
		else if (strcmp(palavra, (*root)->palavra_left) < 0)
			dttDelete(root, &(*root)->left, palavra);
		else if((*root)->total_keys == 1)
			dttDelete(root, &(*root)->cen, palavra);
		else if(strcmp(palavra, (*root)->palavra_right) < 0)
			dttDelete(root, &(*root)->cen, palavra);
		else
			dttDelete(root, &(*root)->right, palavra);
		
	}
	
}