#ifndef _23T_H_
#define _23T_H_

typedef struct DTT * DTT;
#include "dtt_node.h"

struct DTT
{
    DTNode root;
    int total_infos;
};

DTT dttStart();
void dttPrint(DTNode root);
void getTotalNodes(DTNode root, int *count);
DTNode dttSeach(DTNode node, char *palavra);
DTNode insertNode(DTNode root, char *palavra, DTNode new);
DTNode explodeNode(DTNode *root, DTNode new_node, char *palavra, char *palavra_cen);
DTNode ddtInsert(DTNode parent, DTNode *root, char *palavra, char *palavra_cen);
int contains(DTNode root, char *palavra);
int dttDelete(DTNode *parent, DTNode *root, char *palavra);


#endif