gcc -o Dijkstra Dijkstra.c
.\Dijkstra