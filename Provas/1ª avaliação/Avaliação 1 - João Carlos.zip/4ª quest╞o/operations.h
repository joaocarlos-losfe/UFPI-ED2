#ifndef __OPERATIONS__
#define __OPERATIONS__

#include "./AVL/avl.h"

void op2(AVL arr_tree[], int total_chapter, char *wold_e);
void op3(AVL arr_tree[], int chapter, char *wold_p);

#endif