#ifndef __OPERATIONS__
#define __OPERATIONS__

#include "./BST/bst.h"

void op2(BST arr_tree[], int total_chapter, char *wold_e);
void op3(BST arr_tree[], int chapter, char *wold_p);

#endif