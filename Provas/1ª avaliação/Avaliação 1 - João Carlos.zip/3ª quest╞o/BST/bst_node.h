#ifndef _ABBNODE_H_
#define _ABBNODE_H_

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#include "../linked_list/simple_linked_list.h"
#include "../linked_list/data.h"

typedef struct BSTNode* BSTNode;

struct BSTNode
{
    char key[100];

    List list;

    BSTNode left;
    BSTNode right;
};

BSTNode bstNodeCreate(char *key);
BSTNode bstNodeDestroy(BSTNode node);
void bstNodePrint(BSTNode node);
bool bstNodeIsLeaf(BSTNode node);

#endif