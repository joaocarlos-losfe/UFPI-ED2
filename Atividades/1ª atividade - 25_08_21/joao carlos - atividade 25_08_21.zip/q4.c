#include <stdio.h>
#include <stdlib.h>

int mmcCalc(int numbers[5], int i, int mmc_result)
{
    if(i < 5)
    {

    }

    return 0;
}

int main()
{
    
    //não resolvida
    
    return 0;
}